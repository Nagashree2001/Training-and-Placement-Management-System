<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
  </head>
  <body>
    <div class="signup-form">
      <form action="pl.php" method="post">
        <h1>Placements</h1>
        <input type="text" placeholder="USN" name="usn" class="txtb" required>
        <input type="text" placeholder="Company Name" name="cn" class="txtb" required/>
        <input type="text" placeholder="Aptitude Round" name="ar" class="txtb" >
        <input type="text" placeholder="Group Discussion Round" name="gd" class="txtb" >
        <input type="text" placeholder="HR Round" name="hr" class="txtb" >
        <input type="text" placeholder="Interview" name="interview" class="txtb" >
        <input type="submit" value="Update" class="signup-btn" href="#">

      </form>
    </div>
  </body>
</html>
