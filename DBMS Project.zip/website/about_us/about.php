<?php
$con=mysqli_connect('localhost','root');
mysqli_select_db($con, "tpdb");
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
		</head>
		<body>
		  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		  <a class="navbar-brand" href="#">Welcome to Training and Placement</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item">
		        <a class="nav-link" href="http://localhost/website/index.php">Home</a>
		      </li>
		      <li class="nav-item active">
		      	<a class="nav-link" href="index.php">About us<span class="sr-only">(current)</span></a>
		      </li>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="http://localhost/website/Admin/admin.php">Admin</a>
		      </li>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="http://localhost/website/sign_up/signup.php">Register</a>
		      </li>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="http://localhost/website/login_form/login.php">Login</a>
		      </li>
		</ul>
		</div>
		</nav>
		</body>
		</html>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style2.css">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
  </head>
  <h1>About Us</h1>
	<body>
			<div class="main">
					<p>
						B.N.M. Institute of Technology (also Bhageerathi Bai Narayana Rao Maanay Institute of Technology) is a private technical co-educational school located in Banshankari 2nd Stage, Bangalore, Karnataka, India. The school was established in 2001 and is affiliated to the Visvesvaraya Technological University, Belgaum. It is a part of BNMEI (BNM Educational Institutions), established by the Trust M/s. Bhageerathi Bai Narayana Maanay Charities, which started in 1972. 
						
					</p>
					<br>
			</div>
		</div>
	</body>
</html>