<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style1.css">
    <link href="https://fonts.googleapis.com/css?family=Permanent+Marker" rel="stylesheet">
  </head>
  <body>
    <div class="login-box">
          <form action="log.php" method="post">
          <h1>Login</h1>
            <div class="textbox">
              <i class="fas fa-user"></i>
              <input type="text" placeholder="USN" name="usn" required>
            </div>

            <div class="textbox">
              <i class="fas fa-lock"></i>
              <input type="password" placeholder="Password" name="pwd" required>
            </div>

      <input type="submit" class="btn" value="Sign in" href="#">
      
    </div>
      </body>
    </html>
